# StandardDistance
QGIS Standard Distance Plugin

Standard Distance measures the degree to which features are concentrated or dispersed around the features (point or polygon features). Can be launched for all features of the layer, or grouped by a field value. Also can be use a optional weight field parameter. The Plugin create a new layer with a circle polygon representing the Standard Distance. The radius is equal to the standard distance of the features, and its centered in his mean center coordinates. There are no external library dependencies.
